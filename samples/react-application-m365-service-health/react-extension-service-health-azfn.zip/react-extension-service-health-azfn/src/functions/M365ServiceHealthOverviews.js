"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.M365ServiceHealthOverviews = M365ServiceHealthOverviews;
const identity_1 = require("@azure/identity");
const functions_1 = require("@azure/functions");
const microsoft_graph_client_1 = require("@microsoft/microsoft-graph-client");
const lodash_1 = require("lodash");
async function M365ServiceHealthOverviews(request, context) {
    context.log("Fetching M365 Service Health Overview...");
    const tenantId = process.env.TENANT_ID;
    const clientId = process.env.APP_ID;
    const clientSecret = process.env.APP_SECRET;
    try {
        // Initialize Microsoft Graph client
        const credential = new identity_1.ClientSecretCredential(tenantId, clientId, clientSecret);
        const client = microsoft_graph_client_1.Client.initWithMiddleware({
            authProvider: {
                getAccessToken: async () => {
                    const tokenResponse = await credential.getToken("https://graph.microsoft.com/.default");
                    return tokenResponse.token;
                },
            },
        });
        const response = await client
            .api("/admin/serviceAnnouncement/healthOverviews?$expand=issues")
            .version("v1.0")
            .get();
        const sortedData = (0, lodash_1.sortBy)(response.value, (item) => {
            const status = item.status?.toLowerCase() || "";
            return status === "serviceoperational" ? "z" : status;
        });
        return {
            status: 200,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(sortedData),
        };
    }
    catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        context.error("Error fetching service health:", errorMessage);
        return {
            status: 500,
            body: JSON.stringify({ error: errorMessage || "Internal Server Error" }),
        };
    }
}
functions_1.app.http('M365ServiceHealthOverviews', {
    methods: ['GET'],
    authLevel: 'anonymous',
    handler: M365ServiceHealthOverviews
});
