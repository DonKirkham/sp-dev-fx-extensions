import {
    ClientSecretCredential,
    DefaultAzureCredential,
} from "@azure/identity";
import {
    HttpRequest,
    HttpResponseInit,
    InvocationContext,
    app,
} from "@azure/functions";
import {
    IHealthServices,
    IServiceHealthResults,
} from "../models/IServiceHealthResults";

import { Client } from "@microsoft/microsoft-graph-client";
import { sortBy } from "lodash";

export async function M365ServiceHealthOverviews(
    request: HttpRequest,
    context: InvocationContext
  ): Promise<HttpResponseInit> {
    context.log("Fetching M365 Service Health Overview...");
    const tenantId = process.env.TENANT_ID;
    const clientId = process.env.APP_ID;
    const clientSecret = process.env.APP_SECRET;
    try {
      // Initialize Microsoft Graph client
      const credential = new ClientSecretCredential(
        tenantId,
        clientId,
        clientSecret
      );
      const client = Client.initWithMiddleware({
        authProvider: {
          getAccessToken: async () => {
            const tokenResponse = await credential.getToken(
              "https://graph.microsoft.com/.default"
            );
            return tokenResponse.token;
          },
        },
      });
  
      const response: IServiceHealthResults = await client
        .api("/admin/serviceAnnouncement/healthOverviews?$expand=issues")
        .version("v1.0")
        .get();
  
      const sortedData: IHealthServices[] = sortBy(response.value, (item: IHealthServices) => {
        const status = item.status?.toLowerCase() || "";
        return status === "serviceoperational" ? "z" : status;
      });
  
      return {
        status: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(sortedData),
      };
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      context.error("Error fetching service health:", errorMessage);
      return {
        status: 500,
        body: JSON.stringify({ error: errorMessage || "Internal Server Error" }),
      };
    }
  }

app.http('M365ServiceHealthOverviews', {
    methods: ['GET'],
    authLevel: 'anonymous',
    handler: M365ServiceHealthOverviews
});
